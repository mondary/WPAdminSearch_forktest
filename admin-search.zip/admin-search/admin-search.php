<?php
/*
 *	Plugin Name:		Admin Search
 *	Plugin URL:			http://www.andrewstichbury.com
 *	Description:		Admin Search adds a simple, easy-to-use interface to your WordPress admin site that gives you and your WordPress admin users the ability to search across multiple post types, taxonomies and more in one place.
 *	Version:			1.2.3
 *	Requires at least:	4.9.2
 *	Requires PHP:		5.2
 *	Author:				Andrew Stichbury
 *	Author URI:			http://www.andrewstichbury.com
 *	Text Domain:		admin-search
 *	License:			GPL v2 or later
 *	License URI:		https://www.gnu.org/licenses/gpl-2.0.html
 */



/*
 *	Abort if this file is accessed directly
 */
if ( ! defined( 'WPINC' ) ) {
	die;
}



define( 'ADMIN_SEARCH_VERSION', '1.2.3' );
define( 'ADMIN_SEARCH_VERSION_INT', 123 );



require_once plugin_dir_path( __FILE__ ) . 'settings.php';
require_once plugin_dir_path( __FILE__ ) . 'ui.php';
require_once plugin_dir_path( __FILE__ ) . 'ajax.php';



add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function( $links ) {
	$links = [ '<a href="' . admin_url( 'options-general.php?page=admin-search' ) . '">' . __( 'Settings' ) . '</a>' ] + $links;

	return $links;
} );
