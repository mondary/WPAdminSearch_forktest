jQuery.fn.AS_putCursorAtEnd = function() {
	return this.each( function() {
		var $el = jQuery(this),
			el = this;

		if ( ! $el.is( ':focus' ) ) {
			$el.focus();
		}

		if ( el.setSelectionRange ) {
			var len = $el.val().length * 2;

			setTimeout( function() {
				el.setSelectionRange( len, len );
			}, 1 );
		} else {
			$el.val( $el.val() );
		}

		this.scrollTop = 999999;
	});
};


var admin_search_open = false,
	admin_search_has_results = false,
	admin_search_current_query = '';


function admin_search_modal( args ) {
	if ( typeof args !== 'object' ) {
		args = {};
	}

	if ( args.toggle ) {
		if ( admin_search_open ) {
			args.close = true;
		}
	}

	if ( args.close ) {
		jQuery( '#admin-search-modal' ).remove();
		jQuery( 'body' ).css( { overflow : '' } );
		jQuery( '#wp-admin-bar-admin-search-toggle' ).removeClass( 'hover' );

		admin_search_open = false;
		admin_search_current_query = '';
	} else if ( ! admin_search_open ) {
		if ( wp && typeof wp.template == 'function' ) {
			var admin_search_modal_template = wp.template( 'admin-search-modal-template' );

			jQuery( admin_search_modal_template( {
				value : args.value
			} ) ).appendTo( 'body' );
			jQuery( 'body' ).css( { overflow : 'hidden' } );
			jQuery( '#admin-search-input-field' ).focus();

			if ( jQuery( window ).width() <= 782 ) {
				jQuery( '#wp-admin-bar-admin-search-toggle' ).addClass( 'hover' );
			}

			admin_search_open = true;
		}
	}

	return true;
}


function admin_search_submit_form() {
	jQuery( '#admin-search-input-form' ).submit();
}


jQuery( document ).ready( function( $ ) {
	var typingtimer;


	$( document ).on( 'click', '#admin-search-modal', function( e ) {
		e.stopPropagation();
	} );


	$( document ).on( 'click', function( e ) {
		if ( ! $( e.target ).is( '#wp-admin-bar-admin-search-toggle, #wp-admin-bar-admin-search-toggle *' ) ) {
			admin_search_modal( {
				close : true
			} );
		}
	} );


	$( document ).on( 'click', '#admin-search-modal-background', function() {
		admin_search_modal( {
			close : true
		} );
	} );


	$( document ).on( 'mouseenter', '.admin-search-result-has-link', function() {
		$( '.admin-search-result' ).removeClass( 'admin-search-result-focussed' );
		$( this ).addClass( 'admin-search-result-focussed' );
	} );


	$( document ).on( 'keydown', function( event ) {
		var focusonindex, focuson;

		if ( ( event.ctrlKey || event.metaKey ) && event.keyCode == 83 ) {
			event.preventDefault();

			admin_search_modal( {
				toggle : true
			} );
		} else if ( admin_search_open && event.keyCode == 27 ) {
			if ( admin_search_has_results ) {
				jQuery( '#admin-search-input-field' ).val( '' ).focus();
				jQuery( '#admin-search-modal' ).removeClass( 'admin-search-results-open' );

				setTimeout( function() {
					jQuery( '#admin-search-results' ).empty();
				}, 200 );

				admin_search_has_results = false;
			} else {
				admin_search_modal( {
					close : true
				} );
			}

			return;
		} else if ( admin_search.display_on_keypress && ! admin_search_open && ! $( 'input:not([type="checkbox"]), input:not([type="radio"]), input:not([type="range"]), textarea, select' ).is( ':focus' ) && ! document.activeElement.isContentEditable ) {
			if ( ( ( event.keyCode >= 65 && event.keyCode <= 90 ) || ( event.keyCode >= 48 && event.keyCode <= 57 ) ) && ! event.ctrlKey && ! event.metaKey ) {
				admin_search_modal();
			}
		} else if ( admin_search_open && event.keyCode == 40 && ! event.metaKey && ! event.ctrlKey && ! event.shiftKey && ! event.altKey ) {
			event.preventDefault();

			focusonindex = $( '.admin-search-result-focussed' ).index( '.admin-search-result-has-link' ) + 1;
			focuson = $( $( '.admin-search-result-has-link' ).get( focusonindex ) );

			if ( focusonindex > -1 && focuson.length ) {
				$( '.admin-search-result-has-link' ).removeClass( 'admin-search-result-focussed' );
				focuson.addClass( 'admin-search-result-focussed' );
				focuson.find( 'a' ).focus();

				$( '#admin-search-input-field' ).focus();
			}
		} else if ( admin_search_open && event.keyCode == 38 && ! event.metaKey && ! event.ctrlKey && ! event.shiftKey && ! event.altKey ) {
			event.preventDefault();

			focusonindex = $( '.admin-search-result-focussed' ).index( '.admin-search-result-has-link' ) - 1;
			focuson = $( $( '.admin-search-result-has-link' ).get( focusonindex ) );

			if ( focusonindex > -1 && focuson.length ) {
				$( '.admin-search-result-has-link' ).removeClass( 'admin-search-result-focussed' );
				focuson.addClass( 'admin-search-result-focussed' );
				focuson.find( 'a' ).focus();

				$( '#admin-search-input-field' ).focus();
			}
		} else if ( admin_search_open && $( '.admin-search-result-focussed' ).length && event.keyCode == 13 ) {
			event.preventDefault();

			window.location.href = $( '.admin-search-result-focussed a' ).attr( 'href' );
		} else if ( admin_search_open && event.keyCode == 9 ) {
			setTimeout( function () {
				if ( $( '.admin-search-result-has-link a' ).is( ':focus' ) ) {
					focuson = $( '.admin-search-result-has-link a:focus' ).parent();

					$( '.admin-search-result-has-link' ).removeClass( 'admin-search-result-focussed' );
					focuson.addClass( 'admin-search-result-focussed' );
				}
			}, 1 );
		}
	});


	$( document ).on( 'keyup', function( event ) {
		if ( admin_search_open ) {
			if ( ! $( '#admin-search-input-field' ).val() ) {
				jQuery( '#admin-search-modal' ).removeClass( 'admin-search-results-open' );

				setTimeout( function() {
					jQuery( '#admin-search-results' ).empty();
				}, 200 );
			}
		}
	});


	$( document ).on( 'keyup', '#admin-search-input-field', function() {
		if ( $( this ).val() ) {
			clearTimeout( typingtimer );

			typingtimer = setTimeout( admin_search_submit_form, 500 );
		}
	});


	$( document ).on( 'keydown', '#admin-search-input-field', function() {
		if ( $( this ).val() ) {
			clearTimeout( typingtimer );
		}
	});


	$( document ).on( 'submit', '.admin-search-input-form', function( event ) {
		event.preventDefault();

		var q = $( '#admin-search-input-field' ).val();

		if ( q && typeof q == 'string' && q.length > 1 ) {
			if ( q != admin_search_current_query ) {
				admin_search_has_results = false;
				admin_search_current_query = q;

				if ( ! admin_search_open ) {
					admin_search_modal( {
						value : q
					} );
				}

				var first = true;

				$( '#admin-search-modal' ).addClass( 'admin-search-results-loading' );

				$.get( admin_search.ajax_url, {
					action : 'admin_search_ajax',
					q : q
				}, function( response ) {
					if ( response.error ) {
						console.log( response );
					} else {
						$( '#admin-search-results' ).empty().scrollTop();

						if ( admin_search.include_admin_pages ) {
							$.each( admin_search.menu, function( ) {
								if ( this.name.includes( q.toLowerCase() ) ) {
									if ( response.results.length < 1 ) {
										response.results = new Object();
									}

									if ( typeof response.results.admin == 'undefined' ) {
										response.results.admin = {
											post_type : {
												name : 'admin',
												label : admin_search.admin_pages_label
											},
											posts : []
										};
									}

									response.results.admin.posts.push( {
										id : '',
										edit_post_link : this.edit_post_link,
										title :	this.title,
										date : null,
										status : this.status
									} );

									response.total_results++;
								}
							} );
						}

						if ( response.total_results > 0 ) {
							var admin_search_result_group_template = wp.template( 'admin-search-result-group-template' ),
								admin_search_result_template = wp.template( 'admin-search-result-template' ),
								admin_search_media_result_template = wp.template( 'admin-search-media-result-template' ),
								admin_search_result_group_pagination_template = wp.template( 'admin-search-results-group-pagination-template' );

							$.each( response.results, function() {
								admin_search_has_results = true;

								var results = $( '<div>' );

								if ( typeof this.post_type == 'object' && this.post_type.name == 'attachment' ) {
									$.each( this.posts, function() {
										$( admin_search_media_result_template( this ) ).appendTo( results );
									});
								} else {
									$.each( this.posts, function() {
										this.target = '_self';

										if ( jQuery( '<a>', {
											href : this.edit_post_link
										} ).get( 0 ).hostname != location.hostname ) {
											this.target = '_blank';
										}

										var result = $( admin_search_result_template( this ) );

										if ( first && this.edit_post_link ) {
											result.addClass( 'admin-search-result-focussed' );

											first = false;
										}

										result.appendTo( results );
									});

									if ( this.next_page ) {
										$( admin_search_result_group_pagination_template( this ) ).appendTo( results );
									}
								}

								$( admin_search_result_group_template( {
									post_type_name : this.post_type.name,
									post_type_title : this.post_type.label,
									post_type_shortcut : this.post_type.search_url,
									results : results.html()
								} ) ).appendTo( '#admin-search-results' );
							});

							$( '#admin-search-modal' ).removeClass( 'admin-search-no-results' );
						} else {
							admin_search_has_results = false;

							$( '#admin-search-modal' ).addClass( 'admin-search-no-results' );
							$( '<div>', { id : 'admin-search-results-message' } ).append( $( '<div>', { id : 'admin-search-results-message-content' } ).text( response.message ) ).appendTo( '#admin-search-results' );
						}

						$( '#admin-search-modal' ).addClass( 'admin-search-results-open' );

						setTimeout( function() {
							$( '#admin-search-modal' ).removeClass( 'admin-search-results-loading' );
						}, 200 );
					}
				});
			}
		} else {
			$( '#admin-search-modal' ).removeClass( 'admin-search-results-open' ).addClass( 'admin-search-no-results' );
			$( '#admin-search-results' ).empty();
		}
	});


	$( document ).on( 'submit', '.admin-search-result-group-pagination-form', function( event ) {
		event.preventDefault();

		var q = $( '#admin-search-input-field' ).val(),
			source = $( this ).find( '[name="source"]' ).val(),
			paged = $( this ).find( '[name="page"]' ).val();

		var results = $( '.admin-search-result-group.admin-search-' + source + '-post-type' ),
			pagination = results.find( '.admin-search-result-group-pagination' );

		pagination.addClass( 'admin-search-results-loading' );
		pagination.find( 'button[type="submit"]' ).prop( 'disabled', true );

		$.get( admin_search.ajax_url, {
			action : 'admin_search_ajax',
			q : q,
			source : source,
			paged : paged
		}, function( response ) {
			if ( response.error ) {
				console.log( response );
			} else {
				pagination.remove();

				var admin_search_result_template = wp.template( 'admin-search-result-template' ),
					admin_search_result_group_pagination_template = wp.template( 'admin-search-results-group-pagination-template' );

				$.each( response.results, function() {
					$.each( this.posts, function() {
						this.target = '_self';

						if ( jQuery( '<a>', {
							href : this.edit_post_link
						} ).get( 0 ).hostname != location.hostname ) {
							this.target = '_blank';
						}

						$( admin_search_result_template( this ) ).appendTo( results );
					});

					if ( this.next_page ) {
						$( admin_search_result_group_pagination_template( this ) ).appendTo( results );
					}
				});
			}
		});
	});
});
