<?php
/*
 *	Strip HTML tags and content from menu names
 */
function admin_search_sanitize_menu_name(  $str = ''  ) {

	return trim( strip_tags( preg_replace( '/>.*?</s', '><', $str ) ) );

}


/*
 *	Convert hex color values to RGB values
 */
function admin_search_RGB(  $hex  ) {

	if ( $hex[ 0 ] == '#' )
		$hex = substr( $hex, 1 );

	if ( strlen( $hex ) == 3 ) {
		$hex = $hex[ 0 ] . $hex[ 0 ] . $hex[ 1 ] . $hex[ 1 ] . $hex[ 2 ] . $hex[ 2 ];
	}

	return hexdec( $hex[ 0 ] . $hex[ 1 ] ) . ' ' . hexdec( $hex[ 2 ] . $hex[ 3 ] ) . ' ' . hexdec( $hex[ 4 ] . $hex[ 5 ] );

}


/*
 *	Add plugin assets
 */
function admin_search_load_plugin_assets() {

	if ( ! is_user_logged_in() ) {
		return;
	}

	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}

	if ( ! is_admin() && ! admin_search_setting( 'show_when_viewing_site' ) ) {
		return;
	}

	if ( ! is_admin_bar_showing() ) {
		return;
	}


	wp_enqueue_style( 'admin-search-stylesheet', plugin_dir_url( __FILE__ ) . 'assets/style.css', array(), ADMIN_SEARCH_VERSION );
	wp_enqueue_script( 'admin-search-script', plugin_dir_url( __FILE__ ) . 'assets/script.js', array( 'jquery', 'wp-util', 'underscore' ), ADMIN_SEARCH_VERSION );


	$formatted_menu = array();

	if ( is_admin() ) {
		global $menu, $submenu;

		if ( current_user_can( 'manage_options' ) ) {
			foreach ( $menu as $menu_item ) {
				if ( $menu_item[ 0 ] ) {
					$menu_item_name = admin_search_sanitize_menu_name( $menu_item[ 0 ] );
					$menu_item_title = $menu_item_name;
					$menu_item_url = $menu_item[ 2 ];

					if ( isset( $submenu[ $menu_item[ 2 ] ] ) ) {
						foreach ( $submenu[ $menu_item[ 2 ] ] as $submenu_item ) {
							if ( $submenu_item[ 0 ] ) {
								if ( current_user_can( $submenu_item[ 1 ] ) ) {
									$submenu_item_name = admin_search_sanitize_menu_name( $submenu_item[ 0 ] );
									$submenu_item_title = $submenu_item_name;
									$submenu_item_url = $submenu_item[ 2 ];

									if ( strpos( $submenu_item_url, '.php' ) === false ) {
										$submenu_item_url = 'admin.php?page=' . $submenu_item_url;
									}

									$formatted_menu[ $submenu_item[ 2 ] ] = array(
										'edit_post_link'	=>	admin_url( $submenu_item_url ),
										'name'				=>	strtolower( $submenu_item_name . ' ' . $menu_item_name ),
										'title'				=>	$submenu_item_title,
										'status'			=>	null
									);

									if ( strpos( $submenu_item_name, $menu_item_name ) === false ) {
										$formatted_menu[ $submenu_item[ 2 ] ][ 'status' ] = $menu_item_name;
									}
								}
							}
						}
					} else {
						if ( current_user_can( $menu_item[ 1 ] ) ) {
							if ( strpos( $menu_item_url, '.php' ) === false ) {
								$menu_item_url = 'admin.php?page=' . $menu_item_url;
							}

							$formatted_menu[ $menu_item[ 2 ] ] = array(
								'edit_post_link'	=>	admin_url( $menu_item_url ),
								'name'				=>	strtolower( $menu_item_name ),
								'title'				=>	$menu_item_title,
								'status'			=>	null
							);
						}
					}
				}
			}
		}
	}


	$inline_script = "var admin_search={ajax_url:'" . admin_url( 'admin-ajax.php' );
	$inline_script .= "',display_on_keypress:";
	$inline_script .= admin_search_setting( 'display_on_keypress' ) ? 'true' : 'false';
	$inline_script .= ",include_admin_pages:";
	$inline_script .= admin_search_setting( 'include_admin_pages' ) ? 'true' : 'false';
	$inline_script .= ",menu:" . json_encode( $formatted_menu );
	$inline_script .= ",admin_pages_label:'" . addslashes( htmlentities( __( 'Admin Pages', 'admin-search' ) ) );
	$inline_script .= "'}";

	wp_add_inline_script( 'admin-search-script', $inline_script );


    global $_wp_admin_css_colors;

	$inline_style = "";

	if ( is_admin() && ! in_array( get_user_option( 'admin_color' ), array( 'light', 'modern' ) ) ) {
		$scheme = $_wp_admin_css_colors[ get_user_option( 'admin_color' ) ];

		$inline_style .= ":root{--as-background-color:" . $scheme -> colors[ 1 ];
		$inline_style .= ";--as-background-color-rgb:" . admin_search_RGB( $scheme -> colors[ 1 ] );
		$inline_style .= ";--as-focus-color:" . $scheme -> colors[ 2 ];
		$inline_style .= ";--as-focus-text-color:" . $scheme -> colors[ 3 ];
		$inline_style .= ";--as-primary-color:" . $scheme -> icon_colors[ 'current' ];
		$inline_style .= ";--as-primary-color-rgb:" . admin_search_RGB( $scheme -> icon_colors[ 'current' ] );
		$inline_style .= "}@media (min-width:783px){:root{--as-background-color:" . $scheme -> colors[ 0 ];
		$inline_style .= ";--as-background-color-rgb:" . admin_search_RGB( $scheme -> colors[ 0 ] );
		$inline_style .= "}}";
	}

	wp_add_inline_style( 'admin-search-stylesheet', $inline_style );

}

add_action( 'admin_enqueue_scripts', 'admin_search_load_plugin_assets' );
add_action( 'wp_enqueue_scripts', 'admin_search_load_plugin_assets' );



/*
 *	Add search button to admin bar
 */
function admin_search_add_wb_item( $admin_bar ) {

	if ( ! is_user_logged_in() ) {
		return;
	}

	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}

	if ( ! is_admin() && ! admin_search_setting( 'show_when_viewing_site' ) ) {
		return;
	}

	if ( ! is_admin_bar_showing() ) {
		return;
	}

	$admin_bar -> add_menu( array(
		'id'    =>	'admin-search-toggle',
		'title' =>	'<span class="ab-icon"></span><span class="screen-reader-text">' . __( 'Search WordPress', 'admin-search' ) . '</span>',
		'href'  =>	'#',
		'meta'  =>	array(
			'title' =>		__( 'Search', 'admin-search' ),
			'onclick' =>	'admin_search_modal( { toggle : true } ); return false'
		),
	) );

}


add_action( 'admin_bar_menu', 'admin_search_add_wb_item', 100 );



/*
 *	Add search UI template compontents
 */
function admin_search_ui() {

	if ( ! is_user_logged_in() ) {
		return;
	}

	if ( ! current_user_can( 'edit_others_pages' ) ) {
		return;
	}

	if ( ! is_admin() && ! admin_search_setting( 'show_when_viewing_site' ) ) {
		return;
	}

	if ( ! is_admin_bar_showing() ) {
		return;
	}


	$loading_indicator = '<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="24px" viewBox="0 0 50 50" style="enable-background:new 0 0 50 50;" xml:space="preserve"><path d="M43.935,25.145c0-10.318-8.364-18.683-18.683-18.683c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615c8.072,0,14.615,6.543,14.615,14.615H43.935z" transform="rotate(104.145 25 25)"><animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur="0.6s" repeatCount="indefinite"></animateTransform></path></svg>';
?>
<script id="tmpl-admin-search-modal-template" type="text/html">
<div id="admin-search-modal" class="admin-search-no-results">

	<div id="admin-search-modal-background"></div>

	<div id="admin-search-container">

		<div id="admin-search-input">

			<form id="admin-search-input-form" class="admin-search-input-form" method="get">

				<input type="text" name="q" placeholder="<?php _e( 'Search Keywords', 'admin-search' ); ?>" value="{{{data.value}}}" autocomplete="off" id="admin-search-input-field">

				<button type="submit" id="admin-search-input-submit" tabindex="-1">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve">
						<path d="M24,22.6l-5.9-5.9c1.4-1.8,2.3-4,2.3-6.5C20.4,4.6,15.8,0,10.2,0C4.6,0,0,4.6,0,10.2c0,5.6,4.6,10.2,10.2,10.2 c2.5,0,4.7-0.9,6.5-2.3l5.9,5.9L24,22.6z M2,10.2C2,5.7,5.7,2,10.2,2s8.2,3.7,8.2,8.2s-3.7,8.2-8.2,8.2S2,14.7,2,10.2z" />
					</svg>
				</button>

			</form>

			<div id="admin-search-status-indicator">
				<?php echo $loading_indicator ?>
			</div>

			<?php if ( current_user_can( 'manage_options' ) ) { ?>
			<div id="admin-search-settings-link">
				<a href="<?php echo admin_url( 'options-general.php?page=admin-search' ) ?> " title="<?php _e( 'Settings' ) ?>">
					<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24px" height="24px" viewBox="0 0 24 24" style="enable-background:new 0 0 50 50;" xml:space="preserve">
						<circle cx="12" cy="12" r="2"></circle>
						<circle cx="20" cy="12" r="2"></circle>
						<circle cx="4" cy="12" r="2"></circle>
					</svg>
				</a>
			</div>
			<?php } ?>

		</div>

		<div id="admin-search-results"></div>

	</div>

</div>
</script>

<script id="tmpl-admin-search-result-group-template" type="text/html">
<div class="admin-search-result-group admin-search-{{{data.post_type_name}}}-post-type">

	<div class="admin-search-result-group-title">

		{{{data.post_type_title}}}

		<# if ( data.post_type_shortcut ) { #><div class="admin-search-result-group-shortcut">

			<a href="{{{data.post_type_shortcut}}}" title="<?php _e( 'Advanced search' ) ?>"></a>

		</div><# } #>

	</div>

	<div class="admin-search-results">

		{{{data.results}}}

	</div>

</div>
</script>

<script id="tmpl-admin-search-result-template" type="text/html">
<div class="admin-search-result<# if ( data.edit_post_link ) { #> admin-search-result-has-link<# } #>">

	<# if ( data.edit_post_link ) { #>
	<a href="{{{data.edit_post_link}}}"<# if ( data.target == '_blank' ) { #> target="_blank"<# } #>>
	<# } else { #>
	<span>
	<# } #>

		<div class="admin-search-result-container">

			<div class="admin-search-result-title">

				{{{data.title}}}<# if ( data.status ) { #><span class="admin-search-result-status"> &mdash; {{{data.status}}}</span><# } #>

			</div>

			<# if ( data.date ) { #>

			<div class="admin-search-result-date">

				{{{data.date}}}

			</div>

			<# } #>

		</div>

	<# if ( data.edit_post_link ) { #>
	</a>
	<# } else { #>
	</span>
	<# } #>

</div>
</script>

<script id="tmpl-admin-search-results-group-pagination-template" type="text/html">
<div class="admin-search-result-group-pagination">

	<form class="admin-search-result-group-pagination-form" method="get">

		<input type="hidden" name="source" value="{{{data.post_type.name}}}">

		<input type="hidden" name="page" value="{{{data.next_page}}}">

		<button type="submit">

			<span><?php _e( 'Load More Results' ) ?></span>

			<div class="admin-search-result-group-pagination-status-indicator">
				<?php echo $loading_indicator ?>
			</div>

		</button>

	</form>

</div>
</script>

<script id="tmpl-admin-search-media-result-template" type="text/html">
<div class="admin-search-result">

	<a href="{{{data.edit_post_link}}}">

		<# if ( data.attachment ) { #>

		<div class="admin-search-result-preview">

			{{{data.attachment}}}

		</div>

		<# } else { #>

		<div class="admin-search-result-file">

			<div class="admin-search-result-file-container">

				<img src="{{{data.mime_icon}}}" class="admin-search-result-file-icon">

				<div class="admin-search-result-file-title">{{{data.title}}}</div>

			</div>

		</div>

		<# } #>

	</a>

</div>
</script>
<?php

}

add_action( 'admin_footer', 'admin_search_ui' );
add_action( 'wp_footer', 'admin_search_ui' );
